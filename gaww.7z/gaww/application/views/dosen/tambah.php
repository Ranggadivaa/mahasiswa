<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Dosen</legend>
        <div class="mb-3">
            <label for="jurusan" class="form-label">Nama Dosen</label>
            <input type="text" class="form-control" id="dosen" name="dosen" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('dosen'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>